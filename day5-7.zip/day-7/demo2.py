import numpy as np
data1= [[23,32],[43,21]]
data2=[[41,54],[33,32]]

result = [[data1[i][j] + data2[i][j] for j in range(len(data1[0]))] for i in range(len(data1))]
print(result)

data3=np.array([[23,32],[43,21]])
data4=np.array([[41,54],[33,32]])

resultNew= data3+ data4

print(resultNew) 