import numpy as np

inventory=np.array([
    (101,'Laptop', 7500.0,10),
    (102,'Headphones', 1500.0,50),
    (103,'Mouse', 500.0,100),
    (104,'Monitor', 1200.0,20),
    (105,'keyboard', 1000.0,80),
],dtype=[('id','i4'),('name','U20'),('price','f4'),('stock','i4')])


cart=np.array([
    (101,1),(102,2),(103,3)
],dtype=[('product_id','i4'),('quantity','i4')])

for item in cart:
    product=inventory[inventory['id'] == item['product_id']][0]
    print(f"{product['name']} * {item['quantity']} @ {product['price']} each")

# total Cart Value

total=0.0 
for item in cart:
    product=inventory[inventory['id'] == item['product_id']][0]
    total += product['price'] * item['quantity']
print(f"Total Cart Value: {total}")

# update the stock after purchase
for item in cart:
    idx= np.where(inventory['id'] == item['product_id'])[0][0]
    inventory['stock'][idx] -= item['quantity']
print(f"Inventory after Purchase: {inventory[['name','stock']]}")

# find low stock item
low_stock= inventory[inventory['stock'] <30]
print(f"Low Stock: {low_stock}")

# print total inventory value
total_value= np.sum(inventory['price'] * inventory['stock'])
print(total_value)