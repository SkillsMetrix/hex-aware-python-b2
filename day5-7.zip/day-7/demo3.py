
import numpy as np

data= np.array([2,4,6,8,10])
number=2

result= data+ number
print(result)


data1= ([23,32,43,21])
data2=([41,54,33,32])

result2 = data1+ data2

print(result2)