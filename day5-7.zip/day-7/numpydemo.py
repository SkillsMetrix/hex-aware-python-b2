
import numpy as np
import time
""" demoArrayOne= np.array([23,45,32])

demoArrayTwo= np.array([23,45,32],[44,66,77])

print(demoArrayOne)
print(demoArrayTwo) """

size=1000000
list1=list(range(size))
list2=list(range(size))
arr1= np.array(list1)
arr2=np.array(list2)

# python list
start= time.time()
list_sum= [x+ y for x,y in zip(list1,list2)]
end= time.time()
print("List Addition Time ",end-start)

# numpy addition

start=time.time()

arr_sum=arr1+arr2
end= time.time()
print("Numpy Addition Time ",end-start)
