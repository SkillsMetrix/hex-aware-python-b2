import numpy as np
data1= np.array([23,32,43,22])
data2=np.array([41,54,33,32])

result2 = data1+ data2

print(result2)