compname="hexaware"

comp= lambda func: func.upper()

print(comp(compname))
