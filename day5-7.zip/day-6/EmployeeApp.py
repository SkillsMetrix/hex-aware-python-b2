from AllExceptions import *
class Employee:
    def __init__(self,name,salary,age):

        if not name.strip():
            raise EmptyNameError("Employee Name is empty")
        if age<18:
            raise InvalidAgeError("Invalid Age ,muste be > 18")
        if salary <0:
            raise NegativeSalaryError("Salary cant not be negative")
        
        self.name=name
        self.salary=salary
        self.age=age

    def __str__(self):
        return f" Employee Name: {self.name} , Age: {self.age}, Salary: {self.salary}"
    

try:
    empData= Employee("John",60000,17)
    print(empData)

except EmptyNameError as e:
    print("Name is empty ",e)
except NegativeSalaryError as e:
    print("salary negative ",e)
except InvalidAgeError as e:
    print("Age is wrong ",e)        
        