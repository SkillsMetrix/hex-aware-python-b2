# dedicate for employee
class InvalidAgeError(Exception):
    pass

class NegativeSalaryError(Exception):
    pass

class EmptyNameError(Exception):
    pass

# dedicated for shopcart
class ItemNotFoundError(Exception):
    pass

class EmptyCartError(Exception):
    pass