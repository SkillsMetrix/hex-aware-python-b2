
try:
    n=10
    res=100/n
except ZeroDivisionError:
    print('wrong value,pass other thn zero')

except ValueError:
    print('enter a valid number')

else:
    print("Value ",res)

finally:
    print("call it anytime")