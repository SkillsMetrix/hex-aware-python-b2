

dataA=["20","user",40]

try:
    totalValue=int(dataA[0] + int(dataA[2]))
except(ValueError,TypeError) as e:
    print("Error ",e)

except IndexError:
    print("position of data not found")