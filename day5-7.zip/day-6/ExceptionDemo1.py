
basicNumber=10
response=0

try:

    response= basicNumber/10

except ZeroDivisionError:
    print('enter correct value')

print(response)