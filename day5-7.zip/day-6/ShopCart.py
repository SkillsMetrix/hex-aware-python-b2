from AllExceptions import ItemNotFoundError,EmptyCartError
class ShoppingCart:
    def __init__(self):
        # dictionary
        self.items={}
    
    def addItems(self,name,price):
        self.items[name]=price
        print(f"Added {name} - ${price}")
    
    def removeItems(self,name):
        if name not in self.items:
            raise ItemNotFoundError(f" Item not found {name}")
        del self.items[name]
        print(f"Removed {name} from the cart")

    def calculateTotal(self):
        if not self.items:
            raise EmptyCartError("Cart is Empty")
        total= sum(self.items.values())
        print(f"Total Value:  {total}")
        return total
        


cart= ShoppingCart()
try:

    print("==== Added items in cart=====")
    cart.addItems("Laptop",5000)
    cart.addItems("Mouse",1000)

    print("==== Remove items in cart=====")

    cart.removeItems("Laptop2")
    cart.calculateTotal()
except ItemNotFoundError as e:
    print("Item error ",e)
except EmptyCartError as e:
    print ("Cart Error ",e)

