
def addAge(age):
    if age < 18:
        raise ValueError("Age must be 18 and above for voting")
    print(f"Age is {age}")


try:
    addAge(17)
except ValueError as e:
    print(e)

