
from db import (create_table,insert_employee,load_employees,update_emp,search_emp,delete_emp,read_employees)
from employee import Employee
import logging
from pathlib import Path
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill,Font,Alignment
from openpyxl.utils import get_column_letter
import sqlite3
from exception import EmployeeNotFoundError,InvalidInputError,DatabaseOperationError

# configuring Logs

logging.basicConfig(
    level=logging.INFO,
    format= "%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("employee_app.log",mode="a"),
        logging.StreamHandler()
    ]
)
logger= logging.getLogger(__name__)

def display_menu():
    print("\n------ Employee DB App------")
    print("1---- Add Employee------")
    print("2---- load Employees------")
    print("3---- search Employee------")
    print("4---- delete Employee------")
    print("5---- update Employee------")
    print("6---- DataFrame Employee------")
    print("7---- Exit App------")

def main():
    try:
        create_table()
        logger.info("Database Table Created")

    except sqlite3.Error as e:
        raise DatabaseOperationError("Error while creating table")

    while True:
        try:
            display_menu()
            choice= input("Enter Choice to Perform Operations:  ")
            if choice == '1':
                try:
                    emp_id= int(input('Enter Employee ID: '))
                    name=input('Enter Employee Name: ')
                    dept=input('Enter Department department: ')
                    salary= int(input('Enter Employee Salary: '))
                    emp= Employee(emp_id,name,dept,salary)
                    insert_employee(emp)
                    print('Employee Added')
                    logger.info(f"Employee {emp_id} added into DB")
                except ValueError:
                    raise InvalidInputError("ID and salary must be numeric")
                except sqlite3.Error as e:
                    raise DatabaseOperationError("Insert Operation Failed")
        
            elif choice =='2':
                try:
                    employees= load_employees()
                    if not employees:
                        raise EmployeeNotFoundError("No Employee Found")

                    for emp in employees:
                     print(emp)
                     logger.info(f"Loaded {len(employees)} employees from DB")
                except sqlite3.Error as e:
                    raise DatabaseOperationError("Load Operation Failed")
        
            elif choice =='3':
                try:
                    emp_id= int(input('Enter Employee ID to Search'))
                    emp= search_emp(emp_id)
                    if not emp:
                        logger.warning(f"Employee {emp_id} not found")
                        raise EmployeeNotFoundError("Employee ID Not found")
                       
                    print(emp)
                   
                    
                except ValueError:
                    raise InvalidInputError("ID must be numeric")
                except sqlite3.Error as e:
                    raise DatabaseOperationError("Fetch Operation Failed")
          
        
            elif choice =='4':
                try:
                    emp_id= int(input('Enter Employee ID to Search'))
                    delete_emp(emp_id)
                    print('Employee deleted')
                except ValueError:
                    raise InvalidInputError("ID must be numeric")
                except sqlite3.Error as e:
                    raise DatabaseOperationError("delete Operation Failed")
        
            elif choice =='5':
                try:
                    emp_id= int(input('Enter Employee ID to update'))
                    emp= search_emp(emp_id)
                    if not emp:
                         raise EmployeeNotFoundError("Employee ID Not found")
                        
            
                    name=input(f'Enter new Employee Name: ({emp.name}) :)') or emp.name

                    dept=input(f'Enter new Department : ({emp.department}) :)') or emp.department
                    salary_input= int(input(f"Enter new salary ({emp.salary})"))
                    salary= float(salary_input) if salary_input else emp.salary
                    update_emp(Employee(emp_id,name,dept,salary))
                    print("Employee Updated")
                
                except ValueError:
                    raise InvalidInputError("Salary must be numeric")
                except sqlite3.Error as e:
                    logger.error(f"Database Operations error")

            elif choice =='6':
                read_employees()
                


            elif choice =='7':
                print('Exiting the App')
                break
            else:
                print('Wrong Choice')

        except EmployeeNotFoundError as e:
            print('employee not found')
        except InvalidInputError as e:
            print('invalid input')
        except DatabaseOperationError as e:
            print('Database error')

if __name__ == '__main__':
    main()