
class EmployeeError(Exception):
    pass

class EmployeeNotFoundError(EmployeeError):
    pass

class InvalidInputError(EmployeeError):
    pass

class DatabaseOperationError(EmployeeError):
    pass