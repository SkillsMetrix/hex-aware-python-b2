import sqlite3
from employee import Employee
import pandas as pd
DB_NAME="employee.db"

def connect_db():
    conn= sqlite3.connect(DB_NAME)
    return conn

def create_table():
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('''
        create table if not exists employee(
        emp_id INTEGER PRIMARY_KEY,
        name TEXT NOT NULL,
        department TEXT NOT NULL,
        salary REAL NOT NULL
        )
        ''')
    conn.commit()
    conn.close

def insert_employee(emp:Employee):
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('insert into employee(emp_id,name,department,salary) values(?,?,?,?)',
    (emp.emp_id,emp.name,emp.department,emp.salary))
    conn.commit()
    conn.close

def load_employees():
     conn= connect_db()
     cursor= conn.cursor()
     cursor.execute("select * from employee")
     rows= cursor.fetchall()
     conn.close()
     return [Employee(*row) for row in rows]

def search_emp(empid):
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('select * from employee where emp_id=?',(empid,))
    row= cursor.fetchone()
    conn.close
    return Employee(*row) if row else None

def delete_emp(empid):
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('delete from employee where emp_id=?',(empid,))
    conn.commit()
    conn.close

def update_emp(emp:Employee):
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('update employee set name=?,department=?,salary=? where emp_id=?',
                   (emp.name,emp.department,emp.salary,emp.emp_id)
                   )
    conn.commit()
    conn.close

def read_employees() -> pd.DataFrame:
    conn= connect_db()
    
    df=pd.read_sql_query("SELECT emp_id,name,department,salary from employee order by emp_id",conn)
    conn.close()
    return df
