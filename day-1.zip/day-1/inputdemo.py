
uname,age,city= input('Enter your Details ').split()

print(f"Welcome .. {uname} and age is {age} , and city is {city}")