
userNames= ['admin','manager','qa']

print(userNames[2])

# statndard output
for uname in userNames:
    print(f"Details: {uname}")

# with index positions

for index,uname in enumerate(userNames):
    if index == 2:
        print(f" Index: {index} -> {uname}")

#converting enumerate to list

cities=['NY','LA','MEL']
results= list(enumerate(cities))
print(results)

  


