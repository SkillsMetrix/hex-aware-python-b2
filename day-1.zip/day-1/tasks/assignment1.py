
a= int(input('Enter first value '))
b= int(input('Enter first value '))

c=a+b
print(f"Addition is {c}")