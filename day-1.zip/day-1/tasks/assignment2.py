
userAge= input('Enter User Age: ')
age= int(userAge)
if age <= 0:
    print("enter Valid Age")
elif age <18:
    print('Not Allowed to vote')
elif age >=18 and age<79:
    print('You Can Vote')
else:
    print('Senior Citizen')
