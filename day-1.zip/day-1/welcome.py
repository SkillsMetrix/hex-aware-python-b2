
# print('welcome to python')

# declaring var in python

name='john'
city='sam'
age=20

print(name,city,age)
print('My Name is ',name ,'My City is ',city, 'and my age is ', age )
print(f"My Name is {name}, ,My City is: {city}  and my age is {age} ")

a=29
if a>=30:
    print('its true')
else:
    print('its false')
