from abc import ABC,abstractmethod

class RBI(ABC):
    @abstractmethod
    def depositAmount():
        pass
    @abstractmethod
    def checkBalance():
        pass
    @abstractmethod
    def withdrawAmount():
        pass