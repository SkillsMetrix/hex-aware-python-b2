from itertools import zip_longest
#zip (combines 2 arrays )
user_name=['Adma','Sara','surya','sam']
scores=[45,43,44]

result = list(zip_longest(user_name,scores,fillvalue="N/A"))

print(result)

#for name,score in zip(user_name,scores):
   # print(f"{name} scored {score}")

#sorted
#sorted_values= sorted(scores)
#print("Sorted Values ",sorted_values)


