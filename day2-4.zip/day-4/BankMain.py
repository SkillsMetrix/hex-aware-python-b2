
from PublicBank import PublicSector

class BankMain:
    bank= PublicSector()
    bank.openLocker()