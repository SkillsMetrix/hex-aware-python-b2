# class declaration
class User:
    name='shashi'
    state='MH'

    #constructors

    def __init__(self,email,city):
        self.email=email
        self.city=city

    def __str__(self):
        return f"{self.email} - {self.city}"
    
    def showDetails(self):
        print(f"UserName is {self.name} and state is {self.state}")


# object creation

user1= User('admin@mail.com','Pune')
user2= User('hr@mail.com','Mumbai')
print(user1)
print(user2)
#user.showDetails()


