employees=[
    {"name":"Alice","age":24,"city":"Mumbai"},
    {"name":"Bob","age":30,"city":"Delhi"},
    {"name":"David","age":28,"city":"Pune"},
    {"name":"Charlie","age":22,"city":"Delhi"},
    {"name":"Eva","age":35,"city":"Mumbai"}
]
# print name
name=[emp["name"] for emp in employees]
print(name)

# age > 25

name=[emp["name"] for emp in employees if emp["age"] > 25]
print(f"Younger Employees {name}")

# mumbai
name=[emp["name"] for emp in employees if emp["city"].lower() =="mumbai"]
print(f"Mimbai Employees {name}")

user_summary=[f"{emp['name']} from {emp['city']} is {emp['age']} years old" for emp in employees]

for data in user_summary:
    print(data)