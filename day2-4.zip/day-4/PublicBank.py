from rbiapp import RBI

class PublicSector(RBI):

    def openLocker(self):
        print('locker opened')
    def depositAmount():
        print('deposit in public bank')
    
    def checkBalance():
        print('check balance in public bank')
     
    def withdrawAmount():
         print('withdraw in public bank')
