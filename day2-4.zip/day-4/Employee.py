
class Employee:
    company_name='Hexaware'

    def __init__(self,name,salary):
        self.name=name
        self.salary= salary
    @classmethod
    def change_company(cls,new_name):
        cls.company_name=new_name
    @staticmethod
    def is_working_day(day):
        return day.lower() not in ['saturday','sunday']
    
    def display_data(self):
        print(f" {self.name} works at {Employee.company_name} with salary {self.salary}")


empdata=Employee('sam',5000)
empdata.display_data()

Employee.change_company('Hexaware Global')

empdata2=Employee('Alice',4000)
empdata2.display_data()

print(Employee.is_working_day("Monday"))
print(Employee.is_working_day("saturday"))



    