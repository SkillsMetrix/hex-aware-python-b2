
class Employee:
     def __init__(self,name,email,salary):
        self.uname=name
        self.uemail=email
        self.usalary= salary

     @property
     def email(self):
         return f"{self.uemail.lower()}@hexaware.com"
     @property
     def name(self):
         return f"{self.uname}"
     @property
     def salary(self):
         return f"{self.usalary}"
     
     @salary.setter
     def salary(self,value):
         if value < 0:
            raise ValueError("Salary must be no negative")
         self.usalary=value

emp= Employee('user1','user@mail.com',12345)
print(emp.email)
emp.salary=-1
print(emp.salary)