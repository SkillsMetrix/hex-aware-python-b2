empids=[101,102,103,104]
user_name=['Adma','Sara','surya','pam']
income=[2345,4456,3214,4444]


employees= list(zip(empids,user_name,income))
print("Printing Details")
for emp in employees:
    print(emp)
print("salaries > 4k")
for eid,name,salary in employees:
    if(salary > 4000):
        print(f"{eid}- {name}- {salary}")