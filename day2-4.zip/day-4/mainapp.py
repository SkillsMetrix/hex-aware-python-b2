from taskfunclass import StudentManager

main= StudentManager()
main.menu()