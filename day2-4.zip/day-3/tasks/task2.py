# global dictionary
students={}

def add_student():
    """ Add a new student to the dictionary"""
    name= input("enter student name: ").strip()
    if not name:
        print("name cannot be empty .")
        return
    if name in students:
         print(f" Student {name} already exist")
    else:
        students[name]=[]
        print(f" Student {name} is added successfully")
        
def view_students():
    """ Display all the students""" 
    if not students:
        print("No Student found") 
        return   
    print("\n Student Marks and Name")
    for student,marks in students.items():
        marks_display = ", ".join(map(str,marks)) if marks else "No marks yet"
        print(f" {student} : {marks_display}")
        
def add_marks():
    """Adding the Marks to the student"""  
    name= input('Enter Student Name ').strip()
    if name not in students:
            print("student name not found, add the student first")
            return
    try:
        mark= float(input('Enter mark(numeric)'))
        if mark < 0:
            print('Enter non negative value')
            return
        students[name].append(mark)
        print('added')
    except ValueError:
        print("invalid input ,please enater number")
       
def calculate_avg():
    """ calculating  student avg marks"""
    name= input("Enter Student Name: ").strip()
    if name not in students:
        print('student not found')
        return
    if not students[name]:
        print('no marks found for the said student ')
        return
    avg= sum(students[name])/len(students[name])
    print(f" Average marks for {name}: {avg:.2f}")

while True:
    print("\n ======= Student App Manager======")
    print("1, Add new Student")
    print("2, Add MArks for an existing student")
    print("3, View All students")
    print("4, calculate avg marks of the student")
    print("5, Exit")

    user_choice= input("Enter your choice: ")

    if user_choice == "1":
      add_student()
    elif user_choice == "2":
      add_marks()
    elif user_choice == '3':
        view_students()
    elif user_choice == '4':
        calculate_avg()
    elif user_choice == '5':
        print("Exit called")
        break
    else:
        print("Invalid Input")