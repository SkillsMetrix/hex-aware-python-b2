""" 
def sumOfArray(arr):
    total=0
    for num in arr:
        total +=num
    return total

numbers=[13,13,13,13]
result= sumOfArray(numbers)
print(f" Addition is. {result}")
 """


""" def sumOfArray(*arr):
    total=0
    for num in arr:
        total +=num
    return total

result= sumOfArray(13,13,13,13)
print(f" Addition is. {result}") """

#dictionary demo
userData= {101:'user1',102:'user2'}
print(userData.get(101))

del userData[101]
print(userData)

users={101:'amit',102:'shreya',103:{'dep':'Finance','dep1':'testing'}}
print(users.get(103))

def print_user_info(**kwargs):
    print(" keyword arguments ",kwargs)
    for key, value in kwargs.items():
        print(f"{key}: {value}")
print_user_info(name='John',age=45,city='NY')