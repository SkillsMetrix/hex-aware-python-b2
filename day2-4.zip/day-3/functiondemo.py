
def showName():
    print('welcome to function')

def showAndTakeName(inputName):
    #print(inputName)
    return inputName

def showAndTakeNameDefault(inputName='sam'):
    print(inputName)

showName()
print(showAndTakeName('admin'))
showAndTakeNameDefault('tom')