user_data=[]

data= int(input('How Many values you wana add?:  '))

for i in range(data):
    num= int(input(f" Enter number "))
    user_data.append(num)
print(f"The Array Value is: {user_data} ")

# calculate even and odd

for num in user_data:
    if(num%2 ==0):
        print(f"{num} is even number")
    else:
        print(f"{num} is odd number")

# calculate the addition of all the values in array

total=0
for data in user_data:
    total +=data
print(f"Addition is {total}")