students={}

while True:
    print("\n ======= Student App Manager======")
    print("1, Add new Student")
    print("2, Add MArks for an existing student")
    print("3, View All students")
    print("4, calculate avg marks of the student")
    print("5, Exit")

    user_choice= input("Enter your choice: ")
    if user_choice == "1":
        name= input('Enter Student Name ')
        if name not in students:
            students[name]=[]
            print(f" Student {name} is added")
        else:
            print(f" Student {name} already exist")
    
    elif user_choice == "2":
        name= input('Enter Student Name ')
        if name in students:
            mark= input("enter student mark ")
            if mark.isdigit():
                students[name].append(int(mark))
                print(f"Mark {mark} added for {name}")
    elif user_choice == '3':
        if students:
            print("\n Student Marks and Name")
            for student,marks in students.items():
                print(f" {student} : {marks}")
        else:
            print("No Student found")
    elif user_choice == '5':
        print("Exit called")
        break
    else:
        print("Invalid Input")