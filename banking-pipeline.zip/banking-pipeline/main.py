from logger import logger
from db_utils import create_database,export_db_to_csv
from file_utils import create_customer_details_csv
from transformations import join_and_transform
from report import generate_report

def main():
    logger.info('Pipeline Started')
    try:
        create_database()
        export_db_to_csv()
        create_customer_details_csv()
        df_active=join_and_transform()
        generate_report(df_active)
        logger.info('Pipeline Completed')
    except Exception as e:
        logger.error(f"Pipeline Failed: {e}")

if __name__ == '__main__':
    main()